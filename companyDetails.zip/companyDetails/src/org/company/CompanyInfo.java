package org.company;

public class CompanyInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CompanyInfo Company=new CompanyInfo();
		Company.companyName();
		Company.companyId();
		Company.companyAddress();
		
	}
	public void companyName() {
		System.out.println("wipro");
	}
		
	public void companyId() {
		System.out.println("2468");
	}

	public void companyAddress() {
		System.out.println("no.13 gandhi nagar adayar");
	}
	
		
	}
