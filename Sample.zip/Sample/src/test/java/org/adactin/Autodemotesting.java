package org.adactin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Autodemotesting {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file=new File ("F:\\velu smarttt\\Workspace\\Sample\\src\\test\\java\\org\\adactin\\Autodemotesting.java");
		// get the objects,bytes from file
		FileInputStream stream = new FileInputStream(file);
		//create the workbook 
	Workbook workbook=new XSSFWorkbook(stream);
		//get the sheet name
		Sheet sheet=workbook.getSheetAt(0);
		//get the row
		Row row = sheet.getRow(3);
		//get the cell
		Cell cell = row.getCell(2);
		//rows count
		int rowcount = sheet.getPhysicalNumberOfRows();
		//iterate the cells
		for (int i = 0; i< sheet.getPhysicalNumberOfRows() ; i++) {
		//get the each row
		Row row2 = sheet.getRow(i);
		//Iterate the cells
		for (int j = 0; j < row.getPhysicalNumberOfCells(); j++) {
			//get the each cell
			Cell cell2 = row.getCell(j);
			//print the cell value
			System.out.println(cell);
		}
			
		}
		
		
	
	}

}
