package org.adactin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Adactin {
	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://adactinhotelapp.com/");
		WebElement txtuser = driver.findElement(By.xpath("//input[@id='username']"));
		txtuser.sendKeys("velu");
		WebElement txtpass = driver.findElement(By.xpath("//input[@id='password']"));
		txtpass.sendKeys("monster");
		Thread.sleep(3000);
		WebElement btnclick = driver.findElement(By.xpath("//input[@id='login']"));
		btnclick.click();
		driver.quit();
	}
}
