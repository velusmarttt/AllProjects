package ExcelNew.project;

public class Dec0718Questions {
public static int x=0;
int z=9;
int q;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Dec0718Questions obj=new Dec0718Questions();
obj.method1();
obj.method2();
	}
void method1() {
	int s;
	int w=q+7;
	 int y=x;
	x=50;
	System.out.println(w);
	
}

void method2() {
	System.out.println(x);
	
}
static void method3() {
	int y=x;
}
}
