package ExcelNew.project;

public class Baseclassadactin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
