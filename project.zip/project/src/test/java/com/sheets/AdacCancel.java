package com.sheets;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import ExcelNew.project.BaseClass;
import ExcelNew.project.LibGlobal;

public class AdacCancel extends BaseClass {
	
	public String getdataresult() {
		PageFactory.initElements(driver, this);
	}
	
	
	
	
	@FindBy(xpath="//input[@id='order_no']")
	private WebElement datatxtorderno;
	
	@FindBy(xpath="//input[@id='my_itinerary']")
	private WebElement databtnlogin;
	
	@FindBy(xpath="")
	private WebElement data;
	
	

	

	
	
	
	
	
	
	
	

}
