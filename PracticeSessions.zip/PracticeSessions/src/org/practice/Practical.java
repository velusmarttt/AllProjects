package org.practice;

		public class Practical {
			public static void main(String[] args) {
				Practical P=new Practical();
				P.jre();
			}
		public void jre() {
			System.out.println("java run time environment");
		
	}
		}

 