package org.practice;

	public class Theory extends Practical{
	public static void main(String[] args) {
		Theory T=new Theory();
		T.jre();
	}
	
		public void jre() {
		System.out.println("java run time environment");
		
		super.jre();
		
			}

}
