package org.phone;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class CellPhones{
	static int x=0;
	int y=x;
	public void Mobiles() {
		int i=10;
		int g=x;
		System.out.println("5g mobiles is good");
	}
	
	public static void method() {
		CellPhones cell=new CellPhones();
		cell.Mobiles(); 
		method1("f");
	}
	public static void method1(String s) {
		System.out.println(s);
		
		try {
			
		}
		catch(NullPointerException E) {
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		finally {
			
		}
		
		
	}
	public String method2() {
		add(4, 5);
		CellPhones cell=new CellPhones();
		cell.add(2, 4);
		return "vel";
		
		 
	}
	public   int add(int a,int b) {
		int c=a+b;
		return c;
	}

}
