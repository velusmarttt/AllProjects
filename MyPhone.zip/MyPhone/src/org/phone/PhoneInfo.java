package org.phone;

public class PhoneInfo {
	public static void  main(String[]args){
		
		PhoneInfo Phone=new PhoneInfo();
		Phone.storage(); 
		Phone.phoneName();
		Phone.camera();
		Phone.osName();
		Phone.phoneMieinum();
		
	}

	public void phoneName() {
		System.out.println("realme");
	
	}
	public void phoneMieinum() {
		System.out.println("245675");
	}
	public void camera() {
		System.out.println("backcamera is 64mp");
	}
	public void storage() {
		System.out.println("128gb");
	}
	public void osName() {
		System.out.println("windows8");
	}
}

