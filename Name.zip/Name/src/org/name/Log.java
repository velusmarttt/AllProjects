package org.name;

public interface Log {

}
