package org.name;

public abstract class Binary  {

}
