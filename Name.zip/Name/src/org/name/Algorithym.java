package org.name;

public interface Algorithym{

}
