package org.name;

public class Numeric{

}
