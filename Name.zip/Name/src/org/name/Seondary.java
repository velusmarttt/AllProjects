package org.name;

public abstract class Seondary {

}
