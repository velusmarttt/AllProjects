package org.computer;

public class Bike {

	public static void main(String[] args) {
		// TODO Auto-generated method stub433
		Auto au=new Auto();
		  au.add(30, 20);
		 String s= au.test("Dinesh");
		  System.out.println(s);
		  System.out.println(s.length());
		  int v=s.length();
		  System.out.println(v);
		  
	}
		
	
	
	
	
	
	
}



















