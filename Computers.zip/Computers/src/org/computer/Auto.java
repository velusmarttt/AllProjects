package org.computer;

public class Auto {

	
		public void add(int a,int b) {
		int c=a+b;
		if(c==50) System.out.println("valid");
		else System.out.println("invalid");
	}

		public void stringreturn(String name) {
			String a=name+" is smart";
			System.out.println(a);
			System.out.println(a.length());
		}
		public String test(String name){
		String test=name+" is smart";
		return test;
		

		}	
		
}
