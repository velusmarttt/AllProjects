package org.computer;

public interface Software {
	public abstract void softwareResources();

}
