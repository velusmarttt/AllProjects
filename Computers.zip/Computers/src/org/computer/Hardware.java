package org.computer;

public interface Hardware {
	public abstract void hardwareResources();

}
