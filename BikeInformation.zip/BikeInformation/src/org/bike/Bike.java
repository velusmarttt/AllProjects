package org.bike;

public interface Bike {
	public void cost();
	

	public void speed();
}
	
	
