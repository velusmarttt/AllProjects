package org.bike;

	public class Ktm implements Bike{

		@Override
		public void cost() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void speed() {
			// TODO Auto-generated method stub
			
		}
	}