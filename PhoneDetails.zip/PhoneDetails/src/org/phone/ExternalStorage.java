package org.phone;

public class ExternalStorage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExternalStorage External=new ExternalStorage();
		External.size();
		InternalStorage Internal=new InternalStorage();
		Internal.processorName();
		Internal.ramSize();
	}


	
	public void size() {
		System.out.println("3gb");
	}
}
class InternalStorage{
			
			public static void main(String[] args) {
				InternalStorage Internal=new InternalStorage();
				Internal.processorName();
				Internal.ramSize();
			}
			
			
		
		public void processorName() {
			System.out.println("snapdragon");
		}
		 public void ramSize() {
			 System.out.println("4gb");
		 }
		}
			
